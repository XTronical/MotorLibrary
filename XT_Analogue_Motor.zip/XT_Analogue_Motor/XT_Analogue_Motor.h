// Motor Driver library
// For driving analogue (not stepper) motors at various speeds and directions
// Note that motors should not be connected directly to your micro-controller or they will probably
// damage and break it. Please use a motor driver board such as the L9110.
// (c) XTronical (www.xtronical.com) 2019. 
// This code can be used in any way you wish: adapted/extended/ for profit or not
// No warranty is given as the the merchantability of this software and is used at the users
// own risk, no responsibility will be given to loss or damage due to the use of this software

// The library requires just two output pins per motor and only one of them has to be a PWM pin,
// so in the Arduino (which has 6PWM pins) you could drive up to six motors independently at 
// different speeds in any direction.

#include <Arduino.h>

#define STOPPING_TIME 500				// 5 seconds. The time allowed for the motor to stop if you choose
										// to stop the motor on a direction change.
										// Note, this is not a gradual slow down, the power is
										// removed from the motor and this delay happens, allowing the
										// motor to come to a stop. If you choose not to stop the motor
										// first then the motor will be thrown into reverse immediately
										// which may not be healthy for your design/ motor.

// The main motor class 
class XT_Motor_Class
{
  private:
    uint8_t PWMSpeedPin,DirectionPin;           // the two pins for motor control, PWMSpeedPin must be a PWM pin
                                                // On a Uno or Nano these are pins 3, 5, 6, 9, 10, and 11
                                                // DirectionPin can be a normal pin or PWM pin
    bool Direction=false;
    uint8_t Speed=0;
  public:
   
    // Functions
    XT_Motor_Class(uint8_t PWMPin, uint8_t DirectionPin);
    void SetSpeedRaw(uint8_t PassedSpeed);                        // Sets speed as a value between 0 and 255 (max)
    void SetSpeedRaw(uint8_t PassedSpeed,uint16_t TargetTime);    // as previous but speed takes TargetTime to reach the Speed passed
    void SetSpeed(uint8_t PassedSpeed);                    		// Sets the speed as a Percentage
    void SetSpeed(uint8_t PassedSpeed,uint16_t TargetTime);		// as previous but speed takes TargetTime to reach the Speed passed
    uint8_t GetSpeedRaw();                                 	// returns the current raw motor speed (0 - 255)
    uint8_t GetSpeed();  	                            	// returns the current raw motor speed as a percentage
    void SetDirection(bool TheDirection);					// Sets the current direction, true for one way, false for reverse
    void SetDirection(bool TheDirection, bool Stop);		// As above but will bring the motor to a stop first before changing
															// to the new direction, this is a less brutal way than just reversing
															
	void Reverse(bool Stop);
    bool GetDirection();
};