// Motor Driver library
// For driving analogue (not stepper) motors at various speeds and directions
// Note that motors should not be connected directly to your micro-controller or they will probably
// damage and break it. Please use a motor driver board such as the L9110.
// (c) XTronical (www.xtronical.com) 2019. 
// This code can be used in any way you wish: adapted/extended/ for profit or not
// No warranty is given as the the merchantability of this software and is used at the users
// own risk, no responsibility will be given to loss or damage due to the use of this software

// The library requires just two output pins per motor and only one of them has to be a PWM pin,
// so in the Arduino (which has 6PWM pins) you could drive up to six motors independently at 
// different speeds in any direction.

#include "XT_Analogue_Motor.h"

XT_Motor_Class::XT_Motor_Class(uint8_t PWMSpeedPin, uint8_t DirectionPin)
{
  // the two pins for motor control, PWMPin must be a PWM pin
  // On a Uno or Nano these are pins 3, 5, 6, 9, 10, and 11
  // DirectionPin can be a normal pin or PWM pin.  NB no error will
  // be thrown if you do not use the right pins, just your motor
  // won't perform as you would expect
  
  this->PWMSpeedPin=PWMSpeedPin;
  this->DirectionPin=DirectionPin;
  // initialise the pins for output, according the the documentation this is not 
  // required for using analogWrite on a PWM pin but we'll do it anyway
  pinMode(PWMSpeedPin,OUTPUT);       
  pinMode(DirectionPin,OUTPUT);
  // Set the pins so the motor is stationary, basically both pins will be set to 0V
  digitalWrite(DirectionPin,Direction);   
  analogWrite(PWMSpeedPin,Speed);    
};

void XT_Motor_Class::SetSpeedRaw(uint8_t PassedSpeed,uint16_t TargetTime)
{
  // Sets the speed of the motor, TargetTime is the time it takes in ms
  // to reach new speed. Note this is processor locking, this routine will
  // hog the processor and not return until new speed is reached

  int16_t SpeedDiff;
  float SpeedChangePerMilli;
  uint32_t StartTime,ElapsedTime;
  float StartSpeed;
  StartTime=millis();
  ElapsedTime=0;
  SpeedDiff=Speed-PassedSpeed;
  StartSpeed=Speed;
  if(TargetTime<=0)
    SpeedChangePerMilli=PassedSpeed;                                // No delay, straight to full speed
  else
    SpeedChangePerMilli=float(SpeedDiff)/float(TargetTime);         // how much the speed must change per millisecond, I know we don't have this resolution on the PWM
  while(ElapsedTime<=TargetTime)
  {
	  
    if(TargetTime<=0)
      Speed=SpeedChangePerMilli;
    else
      Speed=StartSpeed-(ElapsedTime*SpeedChangePerMilli);
    if(Direction==LOW)                  
      analogWrite(PWMSpeedPin,Speed);  
    else                                
      analogWrite(PWMSpeedPin,~Speed);            
    ElapsedTime=(millis()-StartTime);
  }
  // Because of rounding/float calcs we may not be at the exact desired speed at this point (but very close) so
  // Just before exit we confirm final speed
  if(Direction==LOW)                  // We can treat PWM pin as normal and just write the Speed to it, job done :)
    analogWrite(PWMSpeedPin,PassedSpeed);   
  else     
    analogWrite(PWMSpeedPin,~PassedSpeed);   
}


void XT_Motor_Class::SetSpeedRaw(uint8_t PassedSpeed)
{
  // Changes speed immediately
  SetSpeedRaw(PassedSpeed,0);
}

void XT_Motor_Class::SetSpeed(uint8_t PassedSpeed)
{
  // Changes speed passed as a % immediately
  if(PassedSpeed>100)
	  PassedSpeed=100;
  SetSpeedRaw(255*(PassedSpeed/100),0);
}

void XT_Motor_Class::SetSpeed(uint8_t PassedSpeed,uint16_t TargetTime)
{
  // Changes speed passed as a % slowly over the time specified in TargetTime (ms)
  SetSpeedRaw(255*(float(PassedSpeed)/100),TargetTime);
}

uint8_t XT_Motor_Class::GetSpeedRaw()
{
  return Speed;
}


uint8_t XT_Motor_Class::GetSpeed()
{
  // return speed as a % - whole integer % only, no decimals
  return uint8_t(round((float(Speed)/255)*100));
}

void XT_Motor_Class::SetDirection(bool TheDirection, bool Stop)
{
  // Sets the direction, if stop is true (default) then will stop the motor first
  // before changing the direction, else it will not stop the motor first and it will
  // apply full reverse current, this is NOT RECOMMENDED for the longevity of your motor
  if(TheDirection==Direction)
    return;                           // If direction no changed then return doing nothing
  // Direction has changed, are we stopping the motor first?
  if(Stop)
  {
    if(Direction==LOW)
      analogWrite(PWMSpeedPin,0);        // turning off power to motor
    else
      analogWrite(PWMSpeedPin,255);      // turning off power to motor
    delay(STOPPING_TIME);                     // Wait 250ms for motor to settle/stop
  }
  Direction=TheDirection;
  digitalWrite(DirectionPin,Direction);
  SetSpeedRaw(Speed);  
}


void XT_Motor_Class::Reverse(bool Stop)
{
    //reverses the current direction of the motor, if stop is true then stops motor first before reversing
	if(Direction)
		SetDirection(false,Stop);
	else
		SetDirection(true,Stop);
}

void XT_Motor_Class::SetDirection(bool TheDirection)
{
  SetDirection(TheDirection,true);
}

bool XT_Motor_Class::GetDirection()
{
  return Direction;
}


